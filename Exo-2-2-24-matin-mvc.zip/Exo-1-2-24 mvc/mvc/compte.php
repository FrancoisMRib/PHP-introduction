<?php

    session_start();

    include './model/modelUser.php';

    $login = "";
    $prenom = "";
    $nom = "";

    //-> Si on est connecté, permet l'affichage des informations du comptes (stoké en $_SESSION)
    if(isset($_SESSION['connected'])){
        $login = $_SESSION['login'];
        $prenom = $_SESSION['firstname'];
        $nom = $_SESSION['name'];
    }

    //Duplicata des deux autres fonctions à faire ?
    //MODIFICATION DU PROFIL
    //Vérifier que le formulaire est soumis
    /*if(isset($_POST['connected'])){
        $login = $_SESSION['login'];
        $prenom = $_SESSION['firstname'];
        $nom = $_SESSION['name'];
    }*/

    //MODIFICATION DU PROFIL
    //Vérification que le formulaire est soumis
    if(isset($_POST['submit'])){
        //Vérifie que les champs sont vides
        if(isset($_POST['name']) and !empty($_POST['name']) and isset($_POST['firstname']) and !empty($_POST['firstname'])) {

            //Nettoie les données
            $nom = sanitize($_POST['name']);
            $prenom = sanitize($_POST['firstname']);

            //J'appelle la fonction du modle qui permet l'UPDATE
            $response = updateUser($nom, $prenom, $_SESSION['id']);

            //Je vérifie la réponse
            if($response[1]){


                //Mettre à jour ma session
                $_SESSION['firstname'] = $prenom ;
                $_SESSION['name'] = $nom ;
            }
            //J'affiche le message de confirmation
            $message = $response[0];
        } else {
            $message = "Veuillez remplir tous les champs" ;
        }
    }
    
    include './controlerNav.php';

    include './vue/header.php';
    include './vue/nav.php'; //-> affiche la navbar
    include './vue/vueCompte.php';
?>