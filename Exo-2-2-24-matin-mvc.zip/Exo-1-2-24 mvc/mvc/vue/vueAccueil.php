
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
</head>
<body>    
    <main>
        <p><?= $formCo //->Permet l'affichage du formulaire de connexion ou de Accueil ?></p>
        <p><?= $message ?></p>

        <p><?= $formSub?></p>
        <p><?= $message ?></p>
    </main>
</body>
</html>