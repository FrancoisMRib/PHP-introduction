<nav>
    <a href="index.php">Accueil</a>
    <?= $linkProfil ?>
    <?= $linkCategory ?>
</nav>