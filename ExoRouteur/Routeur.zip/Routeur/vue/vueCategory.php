<h1>Catégories</h1>
<form action="" method="post">
    <h2>Ajouter une catégories</h2>
    <input type="text" name="category">
    <input type="submit" name="submit">
</form>

<p><?= $message ?></p>

<ul><?= $listCat ?></ul>