    
    <main>
        <?= $formCo //->Permet l'affichage du formulaire de connexion ou de Accueil ?>
        <p><?= $message ?></p>

        <?= $formSign //->Permet l'affichage du formulaire d'inscription ou de Accueil ?>
        <p><?= $messageSign ?></p>
    </main>
</body>
</html>