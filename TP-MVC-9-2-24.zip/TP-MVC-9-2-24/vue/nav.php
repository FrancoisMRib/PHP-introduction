<nav>
    <a href="accueil">Accueil</a>
    <?= $linkProfil ?>
</nav>