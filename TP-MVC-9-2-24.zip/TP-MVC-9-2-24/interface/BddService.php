<?php

interface BddService {
    public function connect(): PDO ;
}

?>